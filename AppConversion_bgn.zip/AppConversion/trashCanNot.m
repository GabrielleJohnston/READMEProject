function trashCanNot(y)
    whos
end